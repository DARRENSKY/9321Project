supermarkets = {'Ashfield': 6, 'Botany Bay': 10, 'Lane Cove': 6, 'Leichhardt': 3, 'Marrickville': 13, 'Mosman': 0,
                'North Sydney': 8, 'Randwick': 16, 'Sydney': 30, 'Waverley': 9, 'Woollahra': 15, 'Auburn': 10,
                'Bankstown': 29, 'Burwood': 9, 'Canterbury': 20, 'Canada Bay': 12, 'Hunters Hill': 4, 'Hurstville': 8,
                'Kogarah': 11, 'Ku-Ring-Gai': 0, 'Manly': 7, 'Parramatta': 37, 'Rockdale': 14, 'Ryde': 18,
                'Strathfield': 9, 'Willoughby': 10, 'The Hills Shire': 34, 'Blacktown': 46, 'Blue Mountains': 19,
                'Camden': 24, 'Campbelltown': 26, 'Fairfield': 27, 'Gosford': 21, 'Hawkesbury': 21, 'Holroyd': 24,
                'Hornsby': 23, 'Liverpool': 31, 'Penrith': 23, 'Pittwater': 6, 'Sutherland Shire': 16, 'Warringah': 16,
                'Wollondilly': 25, 'Wyong': 28, 'Cessnock': 30, 'Kiama': 6, 'Lake Macquarie': 32, 'Maitland': 12,
                'Newcastle': 21, 'Port Stephens': 13, 'Shellharbour': 11, 'Wollongong': 29, 'NSW': 878}


def nb_supermarket(lga):
    return supermarkets[lga]

