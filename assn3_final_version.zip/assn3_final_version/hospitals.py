hospitals = {'Ashfield': 4, 'Botany Bay': 1, 'Lane Cove': 6, 'Leichhardt': 4, 'Marrickville': 6, 'Mosman': 2, 'North Sydney': 8, 'Randwick': 9, 'Sydney': 11, 'Waverley': 8, 'Woollahra': 7, 'Auburn': 4, 'Bankstown': 8, 'Burwood': 4, 'Canterbury': 5, 'Canada Bay': 7, 'Hunters Hill': 3, 'Hurstville': 3, 'Kogarah': 8, 'Ku-Ring-Gai': 0, 'Manly': 2, 'Parramatta': 15, 'Rockdale': 8, 'Ryde': 10, 'Strathfield': 3, 'Willoughby': 9, 'The Hills Shire': 6, 'Blacktown': 17, 'Blue Mountains': 7, 'Camden': 4, 'Campbelltown': 7, 'Fairfield': 14, 'Gosford': 8, 'Hawkesbury': 9, 'Holroyd': 10, 'Hornsby': 13, 'Liverpool': 8, 'Penrith': 8, 'Pittwater': 1, 'Sutherland Shire': 5, 'Warringah': 5, 'Wollondilly': 8, 'Wyong': 8, 'Cessnock': 9, 'Kiama': 2, 'Lake Macquarie': 8, 'Maitland': 2, 'Newcastle': 6, 'Port Stephens': 3, 'Shellharbour': 4, 'Wollongong': 15, 'NSW': 342}


def nb_hospitals(lga):
    return hospitals[lga]
